# embed_task5

## 初始化

注意在src中克隆，包名就叫`embed_task5`。

```bash
mkdir task5
cd task5
mkdir src
cd src
git clone git@gitlab.com:shuusui/embed_task5.git
将wpr_simulation包复制到src下
cd ..
catkin_make
```

